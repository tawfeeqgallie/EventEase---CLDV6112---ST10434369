using System;
using System.IO;
using System.Media;
using System.Threading;

internal class Program
{
    private static void Main(string[] args)
    {
        string basePath = AppDomain.CurrentDomain.BaseDirectory;
        string audioPath = Path.Combine(basePath, "Assets", "ElevenLabs_Text_to_Speech_audio.wav");

        if (File.Exists(audioPath))
        {
            SoundPlayer player = new SoundPlayer(audioPath);
            player.Play();
        }
        else
        {
            Console.WriteLine("Audio file not found: " + audioPath);
        }

        DisplayAsciiArt();

        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine("\nWelcome to the Cybersecurity Awareness Chatbot!");
        Console.ResetColor();

        Console.Write("\nWhat is your name? ");
        string name = Console.ReadLine();

        while (string.IsNullOrWhiteSpace(name))
        {
            Console.Write("Please enter a valid name: ");
            name = Console.ReadLine();
        }

        Console.WriteLine($"\nNice to meet you, {name}!");
        StartChat(name);

        void DisplayAsciiArt()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(@"
 ██████  ███    ██ ██████  ███████ ███    ███  █████  ███    ██ ██████  
██    ██ ████   ██ ██   ██ ██      ████  ████ ██   ██ ████   ██ ██   ██ 
██    ██ ██ ██  ██ ██   ██ █████   ██ ████ ██ ███████ ██ ██  ██ ██   ██ 
██    ██ ██  ██ ██ ██   ██ ██      ██  ██  ██ ██   ██ ██  ██ ██ ██   ██ 
 ██████  ██   ████ ██████  ███████ ██      ██ ██   ██ ██   ████ ██████  
                                                                        
                 ██████ ██    ██ ██████  ███████ ██████                 
                ██       ██  ██  ██   ██ ██      ██   ██                
                ██        ████   ██████  █████   ██████                 
                ██         ██    ██   ██ ██      ██   ██                
                 ██████    ██    ██████  ███████ ██   ██                
            ");
            Console.ResetColor();
        }

        void StartChat(string name)
        {
            while (true)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write($"\n{name}, ask me something about cybersecurity (or type 'exit' to quit): ");
                Console.ResetColor();

                string input = Console.ReadLine().ToLower();

                if (string.IsNullOrWhiteSpace(input))
                {
                    Console.WriteLine("Please enter a valid question.");
                    continue;
                }

                if (input == "exit")
                {
                    Console.WriteLine("Stay safe online! Goodbye!");
                    break;
                }

                if (input.Contains("how are you"))
                {
                    Console.WriteLine("I'm secure and always ready to help!");
                }
                else if (input.Contains("purpose"))
                {
                    Console.WriteLine("I teach people how to stay safe on the internet!");
                }
                else if (input.Contains("what can i ask") || input.Contains("help"))
                {
                    Console.WriteLine("You can ask about password safety, phishing, or safe browsing!");
                }
                else if (input.Contains("password"))
                {
                    Console.WriteLine("Use complex passwords and avoid using the same one for multiple accounts.");
                }
                else if (input.Contains("phishing"))
                {
                    Console.WriteLine("Never click on suspicious links or provide personal information in emails.");
                }
                else if (input.Contains("browsing"))
                {
                    Console.WriteLine("Use HTTPS websites and keep your browser updated.");
                }
                else
                {
                    Console.WriteLine("I didn’t quite understand that. Could you rephrase?");
                }

                Thread.Sleep(300);
            }
        }
    }
}
